def add(num1, num2):
    result = num1 + num2
    print("The addition results are : {}".format(result))

def sub(num1, num2):
    result = num1 - num2
    print("The substraction results are : {}".format(result))

def mul(num1, num2):
    result = num1 * num2
    print("The multiplication results are : {}".format(result))

def div(num1, num2):
    result = num1 / num2
    print("The division results are : {}".format(result))

def mod(num1, num2):
    result = num1 % num2
    print("The modulus results are : {}".format(result))